draw_self();

window_set_cursor(cr_none);
cursor_sprite = obj_cursor;