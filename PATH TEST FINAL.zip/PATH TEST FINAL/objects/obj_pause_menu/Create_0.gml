is_paused = false
puase_surface = 1

menu_options = ["yes?","no."]
menu_index = 0; // 0 = Continue, 1 = Leave