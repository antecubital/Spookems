if (is_paused) {
    // 1. Draw the frozen game snapshot
    if (surface_exists(pause_surface)) {
        draw_surface(pause_surface, 0, 0);
    }
    
    // 2. Overlay a dark semi-transparent tint to dim the background
    var _gui_w = display_get_gui_width();
    var _gui_h = display_get_gui_height();
    draw_set_color(c_black);
    draw_set_alpha(0.6); // 60% opacity
    draw_rectangle(0, 0, _gui_w, _gui_h, false);
    
    // 3. Configure text formatting
    draw_set_alpha(1.0); // Reset alpha back to normal
    draw_set_halign(fa_center);
    draw_set_valign(fa_middle);
    
    // Draw "PAUSED" title
    draw_set_color(c_red);
    draw_text_transformed(_gui_w / 2, _gui_h / 2 - 50, "would you like to exit the path?", 2, 2, 0);
    
    // 4. Draw Menu Choices
    for (var _i = 0; _i < array_length(menu_options); _i++) {
        var _y_offset = _gui_h / 2 + (_i * 40);
        
        if (_i == menu_index) {
            // Style for the currently highlighted option
            draw_set_color(c_red); 
            draw_text(_gui_w / 2, _y_offset, "> " + menu_options[_i] + " <");
        } else {
            // Style for unselected options
            draw_set_color(c_white);
            draw_text(_gui_w / 2, _y_offset, menu_options[_i]);
        }
    }
}