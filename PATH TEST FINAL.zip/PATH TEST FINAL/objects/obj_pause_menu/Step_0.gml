// Toggle pause state
if (keyboard_check_pressed(vk_escape)) {
    is_paused = !is_paused;
    
    if (is_paused) {
        // 1. Create a surface to capture the current screen visual
        var _width = display_get_gui_width();
        var _height = display_get_gui_height();
        pause_surface = surface_create(_width, _height);
        
        // 2. Copy the game screen to our pause surface
        surface_copy(pause_surface, 0, 0, application_surface);
        
        // 3. Deactivate all other instances so they freeze completely
        instance_deactivate_all(true); 
    } else {
        // Clean up surface and reactivate everything when unpausing
        if (surface_exists(pause_surface)) {
            surface_free(pause_surface);
        }
        instance_activate_all();
    }
}

// Menu Navigation (Only functions if the game is actively paused)
if (is_paused) {
    // Navigate menu up/down
    if (keyboard_check_pressed(vk_up) || keyboard_check_pressed(ord("W"))) {
        menu_index--;
        if (menu_index < 0) menu_index = array_length(menu_options) - 1;
    }
    
    if (keyboard_check_pressed(vk_down) || keyboard_check_pressed(ord("S"))) {
        menu_index++;
        if (menu_index >= array_length(menu_options)) menu_index = 0;
    }
    
    // Select an option
    if (keyboard_check_pressed(vk_enter) || keyboard_check_pressed(vk_space)) {
        if (menu_index == 0) {
            // "Continue" Action
            is_paused = false;
            if (surface_exists(pause_surface)) surface_free(pause_surface);
            instance_activate_all();
        } else if (menu_index == 1) {
            // "Leave" Action (Goes back to main menu room or exits game)
            if (surface_exists(pause_surface)) surface_free(pause_surface);
            instance_activate_all(); // Always reactivate before changing rooms
            
            // Adjust this to your actual main menu room name, or use game_end()
            if (room_exists(rm_main_menu)) {
                room_goto(rm_main_menu); 
            } else {
                game_end(); 
            }
        }
    }
}		