if (ds_exists(global.locations, ds_type_map)) {
	ds_map_destroy(global.locations);
}