global.locations = ds_map_create()

rm1 = ds_map_create();
rm1[? "name"] = "rm1";
rm1[? "rooms"] = [
	rm1_rm1_north,
	rm1_rm1_east,
	rm1_rm1_south,
	rm1_rm1_west
];
rm1[? "exits"] = [
	"rm2",
	"",
	"",
	""
];
global.locations[? "rm1"] = rm1;

rm2 = ds_map_create();
rm2[? "name"] = "rm2";
rm2[? "rooms"] = [
	rm2_rm2_north,
	rm2_rm2_east,
	rm2_rm2_south,
	rm2_rm2_west
];
rm2[? "exits"] = [
	"rm2closet",
	"",
	"rm1",
	""
];
global.locations[? "rm2"] = rm2;

rm2closet = ds_map_create();
rm2closet[? "name"] = "rm2closet";
rm2closet[? "rooms"] = [
	rm2_rm2_closet,
	rm2_rm2_closetright
];
rm2closet[? "exits"] = [
	"rm2",
	""
];
global.locations[? "rm2closet"] = rm2closet;

depth = -1;
location_current = "rm1";
direction_facing = 0;
previous_direction = direction_facing;
head_turn = false;
cursor_lock = false;
global.debug = false;
turn_timer_current = 15;
turn_timer = 15;
game_set_speed(30, gamespeed_fps);

