if global.debug = true {
	
draw_self();
draw_set_colour(c_white);
draw_set_alpha(1);
draw_text(x,y,string(location_current));
draw_text(x,y+15, "direction face: " + string(direction_facing));
draw_text(x,y+30, room_get_name(room));
draw_text(x,y+45, "cursor_lock: " + string(cursor_lock));	
draw_text(x,y+60, "head turn: " + string(head_turn));
draw_text(x,y+75, "previous direction: " + string(previous_direction));
}