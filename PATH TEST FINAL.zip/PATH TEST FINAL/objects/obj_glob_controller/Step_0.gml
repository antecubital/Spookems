current_location = global.locations[? location_current];

current_rooms = current_location[? "rooms"];
room_to_go = current_rooms[direction_facing];
current_exits = current_location[? "exits"];
next_location = current_exits[direction_facing];

cursor_x = obj_cursor.x;
cursor_y = obj_cursor.y;

if cursor_lock = false {
	cursor_left = place_meeting(cursor_x, cursor_y,obj_zone_turnL);
	cursor_right = place_meeting(cursor_x, cursor_y,obj_zone_turnR);
	cursor_exitL = place_meeting(cursor_x, cursor_y,obj_zone_exitL);
	cursor_exitR = place_meeting(cursor_x, cursor_y,obj_zone_exitR);
	cursor_forward = place_meeting(cursor_x, cursor_y,obj_zone_forward);
}

if cursor_right and mouse_check_button_released(mb_left)
{
	previous_direction = direction_facing;
	direction_facing += 1;
	image_angle -= 90;
}

if cursor_left and mouse_check_button_released(mb_left)
{
	previous_direction = direction_facing;
	direction_facing -= 1;
	image_angle += 90;
}

if cursor_forward and mouse_check_button_released(mb_left)
{
	if (next_location!= "" and next_location != location_current) {
		location_current = next_location;
	}
	if (room_to_go != -1 and room != room_to_go) {
		room_goto(room_to_go);
	}
}
if (cursor_exitL and mouse_check_button_released(mb_left)) or (cursor_exitR and mouse_check_button_released(mb_left))
{
	if (next_location != "" and next_location != location_current) {
		location_current = next_location;
	}
	if (room_to_go != -1 and room != room_to_go) {
		room_goto(room_to_go);
	}
}

if keyboard_check_pressed(ord("Q")) {
    window_set_fullscreen(!window_get_fullscreen());
}


if (head_turn == true)
{
	if (direction_facing == 0 || direction_facing == 1 || direction_facing == 2 || direction_facing == 3)
	{
		cursor_lock = true;
		turn_timer_current--;
		
	if (turn_timer_current <= 0)
	{
		if (direction_facing = 3 and previous_direction = 0)
		{
		direction_facing -= 1;
		turn_timer_current = turn_timer;
		cursor_lock = false;
		}
		else if (direction_facing > previous_direction)
		{
		direction_facing += 1;
		turn_timer_current = turn_timer;
		cursor_lock = false;
		}
		else
		{
		direction_facing -= 1;
		turn_timer_current = turn_timer;
		cursor_lock = false;
		}
	}
}
}

if direction_facing < 0 {direction_facing = 3}
if direction_facing > 3 {direction_facing = 0}

if (room_to_go != -1 and room != room_to_go) {
	room_goto(room_to_go);
}

if keyboard_check_released(vk_tab)
{
	global.debug = !global.debug;
}

	
	
